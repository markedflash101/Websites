

    const observer = lozad();

    observer.observe();