

    function toggleMobileFooterLinks1() {

        const set1Links = document.getElementById('set-1-links');

        if (set1Links.style.display == 'block') {

            set1Links.style.display = 'none';
            document.getElementById('show-1').innerHTML = "+";
            document.getElementById('show-1').style.color = 'white';
            document.getElementById('show-1').style.transition = '.3s ease-in-out';

        } else {

            set1Links.style.display = 'block';
            document.getElementById('show-1').innerHTML = "<i class='fas fa-times'></i>";
            document.getElementById('show-1').style.color = 'indianred';
            document.getElementById('show-1').style.transition = '.3s ease-in-out';

        }

    }


    function toggleMobileFooterLinks2() {

        const set2Links = document.getElementById('set-2-links');

        if (set2Links.style.display == 'block') {

            set2Links.style.display = 'none';
            document.getElementById('show-2').innerHTML = "+";
            document.getElementById('show-2').style.color = 'white';
            document.getElementById('show-2').style.transition = '.3s ease-in-out';

        } else {

            set2Links.style.display = 'block';
            document.getElementById('show-2').innerHTML = "<i class='fas fa-times'></i>";
            document.getElementById('show-2').style.color = 'indianred';
            document.getElementById('show-2').style.transition = '.3s ease-in-out';

        }

    }


    function toggleMobileFooterLinks3() {

        const set3Links = document.getElementById('set-3-links');

        if (set3Links.style.display == 'block') {

            set3Links.style.display = 'none';
            document.getElementById('show-3').innerHTML = "+";
            document.getElementById('show-3').style.color = 'white';
            document.getElementById('show-3').style.transition = '.3s ease-in-out';

        } else {

            set3Links.style.display = 'block';
            document.getElementById('show-3').innerHTML = "<i class='fas fa-times'></i>";
            document.getElementById('show-3').style.color = 'indianred';
            document.getElementById('show-3').style.transition = '.3s ease-in-out';

        }

    }