
    // Global Variables

    const mobileLogo = document.getElementById('mobileLogo');

    const mobileToggle = document.getElementById('mobileNavToggle');
    const mobileClose = document.getElementById('mobileNavCloser');

    const mobileNav = document.getElementById('mobileNav');

    const servicesLinksToggle = document.getElementById('servicesToggle');
    const servicesLinksCloser = document.getElementById('servicesCloser');

    const aboutLinksToggle = document.getElementById('aboutsToggle');
    const aboutLinksCloser = document.getElementById('aboutsCloser');

    const serviceLinks = document.getElementById('mobileServices');
    const aboutLinks = document.getElementById('mobileAbout');


    function closeLinks() { // This function automatically closes the links if the user does not manually when closing the mobile nav

        serviceLinks.style.display = 'none';

        aboutLinks.style.display = 'none';

        servicesLinksToggle.style.display = 'block';

        servicesLinksCloser.style.display = 'none';

        aboutLinksToggle.style.display = 'block';

        aboutLinksCloser.style.display = 'none';

    };


    // Mobile Toggles

    mobileToggle.addEventListener('click', function() {

        mobileNav.style.display = 'block';

        mobileToggle.style.display = 'none';

        mobileClose.style.display = 'block';

        mobileLogo.style.display = 'none';

        document.body.style.overflow = 'hidden';

    });


    mobileClose.addEventListener('click', function() {

        mobileNav.style.display = 'none';

        mobileToggle.style.display = 'block';

        mobileClose.style.display = 'none';
        
        mobileLogo.style.display = 'flex';

        document.body.style.overflow = 'auto';

        closeLinks(); // This automatically closes the links if the user does not manually when closing the mobile nav

    });


    // Service Toggles

    servicesLinksToggle.addEventListener('click', function() {

        servicesLinksToggle.style.display = 'none';

        servicesLinksCloser.style.display = 'block';

        serviceLinks.style.display = 'grid';

    });

    servicesLinksCloser.addEventListener('click', function() {

        servicesLinksToggle.style.display = 'block';

        servicesLinksCloser.style.display = 'none';

        serviceLinks.style.display = 'none';

    });


    // About Toggles

    aboutLinksToggle.addEventListener('click', function() {

        aboutLinksToggle.style.display = 'none';

        aboutLinksCloser.style.display = 'block';

        aboutLinks.style.display = 'grid';

    });

    aboutLinksCloser.addEventListener('click', function() {

        aboutLinksToggle.style.display = 'block';

        aboutLinksCloser.style.display = 'none';

        aboutLinks.style.display = 'none';

    });

  
    