
let slideIndex = 0;
showSlides();
var slides, dots;


function showSlides() {

    slides = document.getElementsByClassName('slides');
    dots = document.getElementsByClassName('dot');

    let i;
    for (i = 0; i < slides.length; i++) {

        slides[i].style.display = 'none';

    }

    slideIndex++;

    if (slideIndex > slides.length) {slideIndex = 1;}

    for (i = 0; i < dots.length; i++) {

        dots[i].className = dots[i].className.replace(" active", "");

    }

    slides[slideIndex-1].style.display = 'block';
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 12000);

}


function plusSlides(position) {

    slideIndex +=position;

    if (slideIndex > slides.length) {slideIndex = slides.length}

    for (i = 0; i < slides.length; i++) {

        slides[i].style.display = 'none';

    }

    for (i = 0; i < dots.length; i++) {

        dots[i].className = dots[i].className.replace(" active", "");

    }

    slides[slideIndex-1].style.display = 'block';
    dots[slideIndex-1].className += " active";

}


function currentSlide(index) {

    if (index> slides.length) {index = 1} // index (first slide / slideIndex[0])

        else if(index<1){index = slides.length}

        for (i = 0; i < slides.length; i++) {
           slides[i].style.display = "none";  
        }

        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }

        slides[index-1].style.display = "block";  

        dots[index-1].className += " active";

}


// Hides Slider until scrolled down to a specifc px

const slider = document.getElementById('slider');

const scrollFunction = function() {

    let y = window.scrollY;

    if (y >= 100) {

        slider.className = "slider show";

    } else {

        slider.className = "slider hide";

    }

};

window.addEventListener('scroll', scrollFunction);