

const lIMainOne = document.getElementById('li-main-img-1');
const lIMainTwo = document.getElementById('li-main-img-2');
const lIMainThree = document.getElementById('li-main-img-3');
const lIMainFour = document.getElementById('li-main-img-4');


const lISubOne = document.getElementById('li-sub-img-1');
const lISubTwo = document.getElementById('li-sub-img-2');
const lISubThree = document.getElementById('li-sub-img-3');
const lISubFour = document.getElementById('li-sub-img-4');


lISubOne.addEventListener('click', function() {

    lIMainOne.style.display = 'block';
    lIMainTwo.style.display = 'none';
    lIMainThree.style.display = 'none';
    lIMainFour.style.display = 'none';

});

lISubTwo.addEventListener('click', function() {

    lIMainOne.style.display = 'none';
    lIMainTwo.style.display = 'block';
    lIMainThree.style.display = 'none';
    lIMainFour.style.display = 'none';

});

lISubThree.addEventListener('click', function() {

    lIMainOne.style.display = 'none';
    lIMainTwo.style.display = 'none';
    lIMainThree.style.display = 'block';
    lIMainFour.style.display = 'none';

});

lISubFour.addEventListener('click', function() {

    lIMainOne.style.display = 'none';
    lIMainTwo.style.display = 'none';
    lIMainThree.style.display = 'none';
    lIMainFour.style.display = 'block';

});




const kMMainOne = document.getElementById('km-main-img-1');
const kMMainTwo = document.getElementById('km-main-img-2');
const kMMainThree = document.getElementById('km-main-img-3');
const kMMainFour = document.getElementById('km-main-img-4');


const kMSubOne = document.getElementById('km-sub-img-1');
const kMSubTwo = document.getElementById('km-sub-img-2');
const kMSubThree = document.getElementById('km-sub-img-3');
const kMSubFour = document.getElementById('km-sub-img-4');


kMSubOne.addEventListener('click', function() {

    kMMainOne.style.display = 'block';
    kMMainTwo.style.display = 'none';
    kMMainThree.style.display = 'none';
    kMMainFour.style.display = 'none';

});

kMSubTwo.addEventListener('click', function() {

    kMMainOne.style.display = 'none';
    kMMainTwo.style.display = 'block';
    kMMainThree.style.display = 'none';
    kMMainFour.style.display = 'none';

});

kMSubThree.addEventListener('click', function() {

    kMMainOne.style.display = 'none';
    kMMainTwo.style.display = 'none';
    kMMainThree.style.display = 'block';
    kMMainFour.style.display = 'none';

});

kMSubFour.addEventListener('click', function() {

    kMMainOne.style.display = 'none';
    kMMainTwo.style.display = 'none';
    kMMainThree.style.display = 'none';
    kMMainFour.style.display = 'block';

});




const cMMainOne = document.getElementById('cm-main-img-1');
const cMMainTwo = document.getElementById('cm-main-img-2');
const cMMainThree = document.getElementById('cm-main-img-3');
const cMMainFour = document.getElementById('cm-main-img-4');


const cMSubOne = document.getElementById('cm-sub-img-1');
const cMSubTwo = document.getElementById('cm-sub-img-2');
const cMSubThree = document.getElementById('cm-sub-img-3');
const cMSubFour = document.getElementById('cm-sub-img-4');


cMSubOne.addEventListener('click', function() {

    cMMainOne.style.display = 'block';
    cMMainTwo.style.display = 'none';
    cMMainThree.style.display = 'none';
    cMMainFour.style.display = 'none';

});

cMSubTwo.addEventListener('click', function() {

    cMMainOne.style.display = 'none';
    cMMainTwo.style.display = 'block';
    cMMainThree.style.display = 'none';
    cMMainFour.style.display = 'none';

});

cMSubThree.addEventListener('click', function() {

    cMMainOne.style.display = 'none';
    cMMainTwo.style.display = 'none';
    cMMainThree.style.display = 'block';
    cMMainFour.style.display = 'none';

});

cMSubFour.addEventListener('click', function() {

    cMMainOne.style.display = 'none';
    cMMainTwo.style.display = 'none';
    cMMainThree.style.display = 'none';
    cMMainFour.style.display = 'block';

});