
    const images = [];
    function preload() {

        for (let i = 0; i < arguments.length; i++) {

            images[i] = new Image();
            images[i].src = preload.arguments[i];

        }

    }


    preload(

        // Global

        "imgs/logo.png",

        // Index

        "imgs/index/index-hero-img.jpeg",
        "imgs/index/index-why-choose-us-bg.png",
        "imgs/index/index-previews-header-bg.jpg",
        "imgs/index/meat.png",
        "imgs/index/reasons/098f6c69aaeda7d34e245cc9ed942e8e.png",
        "imgs/index/reasons/11719-200.png",
        "imgs/index/reasons/3321304-200.png",
        "imgs/index/product-preview/Ribeye Steak_Lip-on.jpg",
        "imgs/index/product-preview/71t5N03lLeL._SL1500_.jpg",
        "imgs/index/product-preview/istockphoto-106587515-612x612.jpg",
        "imgs/index/product-preview/raw-chicken-drumsticks-500x500.jpg",
        "imgs/index/product-preview/Ribeye Steak_Lip-on.jpg",
        "imgs/index/product-preview/71t5N03lLeL._SL1500_.jpg",
        "imgs/index/product-preview/istockphoto-106587515-612x612.jpg",
        "imgs/index/product-preview/raw-chicken-drumsticks-500x500.jpg",

        // About Us

        "imgs/about/about-us-top-wrapper-darkened.jpg",

        // Store

        "imgs/store/store-top-bg-darkened.jpg"

    )