
const menuToggle = document.getElementById('menu-toggle');
const menuClose = document.getElementById('menu-close');

const mobileNavLinks = document.getElementById('mobile-nav-links');


menuToggle.addEventListener('click', function() {

    menuToggle.style.display = 'none';
    menuClose.style.display = 'block';
    mobileNavLinks.style.display = 'block';

});


menuClose.addEventListener('click', function() {

    menuToggle.style.display = 'block';
    menuClose.style.display = 'none';
    mobileNavLinks.style.display = 'none';

})

