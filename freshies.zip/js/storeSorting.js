
const allBtn = document.getElementById('allSort');
const steaksBtn = document.getElementById('steaksSort');
const porkBtn = document.getElementById('porkSort');
const chickenBtn = document.getElementById('chickenSort');
const venisonBtn = document.getElementById('venisonSort');
const fishBtn = document.getElementById('fishSort');







function steaks() {

    Array.from(document.querySelectorAll('.steakItem'))
        .forEach(function(steak) {

            steak.style.display = 'block';

        });

}


function hideSteaks() {

    Array.from(document.querySelectorAll('.steakItem'))
        .forEach(function(steak) {

            steak.style.display = 'none';

        });

}


function pork() {

    Array.from(document.querySelectorAll('.porkItem'))
    .forEach(function(pork) {

        pork.style.display = 'block';

    });

}


function hidePork() {

    Array.from(document.querySelectorAll('.porkItem'))
    .forEach(function(pork) {

        pork.style.display = 'none';

    });

}



function chicken() {

    Array.from(document.querySelectorAll('.chickenItem'))
    .forEach(function(chicken) {

        chicken.style.display = 'block';

    });

}


function hideChicken() {

    Array.from(document.querySelectorAll('.chickenItem'))
    .forEach(function(chicken) {

        chicken.style.display = 'none';

    });

}


function venison() {

    Array.from(document.querySelectorAll('.venisonItem'))
    .forEach(function(venison) {

        venison.style.display = 'block';

    });

}


function hideVenison() {

    Array.from(document.querySelectorAll('.venisonItem'))
    .forEach(function(venison) {

        venison.style.display = 'none';

    });

}


function fish() {

    Array.from(document.querySelectorAll('.fishItem'))
    .forEach(function(fish) {

        fish.style.display = 'block';

    });

}


function hideFish() {

    Array.from(document.querySelectorAll('.fishItem'))
    .forEach(function(fish) {

        fish.style.display = 'none';

    });

}






// All btn

allBtn.addEventListener('click', function() {

    steaks();

    pork();

    chicken();

    venison();

    fish();

});


// Steaks btn 

steaksBtn.addEventListener('click', function() {

    steaks();

    hidePork();

    hideChicken();

    hideVenison();

    hideFish();

});


// Pork btn 

porkBtn.addEventListener('click', function() {

    hideSteaks();

    pork();

    hideChicken();

    hideVenison();

    hideFish();

});


// Chicken btn 

chickenBtn.addEventListener('click', function() {

    hideSteaks();

    hidePork();

    chicken();

    hideVenison();

    hideFish();

});


// Venison btn 

venisonBtn.addEventListener('click', function() {

    hideSteaks();

    hidePork();

    hideChicken();

    venison();

    hideFish();

});


// Fish btn 

fishBtn.addEventListener('click', function() {

    hideSteaks();

    hidePork();

    hideChicken();

    hideVenison();

    fish();

});








