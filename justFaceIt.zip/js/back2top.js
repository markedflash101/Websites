

    backToTopBtn = document.getElementById('backToTop');

    window.onscroll = function() {scrollFunct()};

    function scrollFunct() {
        if (document.body.scrollTop > 30 || document.documentElement.scrollTop > 30) {
            backToTopBtn.style.display = 'block';
        } else {
            backToTopBtn.style.display = 'none';
        }
    }


    function toTopFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
