






    //! Question Variables

        //* SITE HELP

            //? Question One

                const viewOne = document.getElementById('v-one');
                const hideOne = document.getElementById('h-one');
                const answerOne = document.getElementById('a-one');

            //? Question Two

                const viewTwo = document.getElementById('v-two');
                const hideTwo = document.getElementById('h-two');
                const answerTwo = document.getElementById('a-two');

            //? Question Three

                const viewThree = document.getElementById('v-three');
                const hideThree = document.getElementById('h-three');
                const answerThree = document.getElementById('a-three');


        //* PURCHASING

            //? Question One 

                const viewFour = document.getElementById('v-four');
                const hideFour = document.getElementById('h-four');
                const answerFour = document.getElementById('a-four');

            
            //? Question Two

                const viewFive = document.getElementById('v-five');
                const hideFive = document.getElementById('h-five');
                const answerFive = document.getElementById('a-five');


        //* CUSTOMER SUPPORT

            //? Question One

                const viewSix = document.getElementById('v-six');
                const hideSix = document.getElementById('h-six');
                const answerSix = document.getElementById('a-six');









    //! Question Events

        //* SITE HELP

            //? Question One

                viewOne.addEventListener('click', function() {  // View Answer Btn
                    answerOne.style.display = 'block';
                    viewOne.style.display = 'none';
                    hideOne.style.display = 'block';
                });

                hideOne.addEventListener('click', function() {  // Hide Answer Btn
                    answerOne.style.display = 'none';
                    viewOne.style.display = 'block';
                    hideOne.style.display = 'none';
                });


            //? Question Two

                viewTwo.addEventListener('click', function() {  // View Answer Btn
                    answerTwo.style.display = 'block';
                    viewTwo.style.display = 'none';
                    hideTwo.style.display = 'block';
                });

                hideTwo.addEventListener('click', function() {  // Hide Answer Btn
                    answerTwo.style.display = 'none';
                    viewTwo.style.display = 'block';
                    hideTwo.style.display = 'none';
                });


            //? Question Three 

                viewThree.addEventListener('click', function() {  // View Answer Btn
                    answerThree.style.display = 'block';
                    viewThree.style.display = 'none';
                    hideThree.style.display = 'block';
                });

                hideThree.addEventListener('click', function() {  // Hide Answer Btn
                    answerThree.style.display = 'none';
                    viewThree.style.display = 'block';
                    hideThree.style.display = 'none';
                });

        
        //* PURCHASING

                //? Question One

                    viewFour.addEventListener('click', function() {  // View Answer Btn
                        answerFour.style.display = 'block';
                        viewFour.style.display = 'none';
                        hideFour.style.display = 'block';
                    });

                    hideFour.addEventListener('click', function() {  // Hide Answer Btn
                        answerFour.style.display = 'none';
                        viewFour.style.display = 'block';
                        hideFour.style.display = 'none';
                    });

                
                //? Question Two

                    viewFive.addEventListener('click', function() {  // View Answer Btn
                        answerFive.style.display = 'block';
                        viewFive.style.display = 'none';
                        hideFive.style.display = 'block';
                    });

                    hideFive.addEventListener('click', function() {  // Hide Answer Btn
                        answerFive.style.display = 'none';
                        viewFive.style.display = 'block';
                        hideFive.style.display = 'none';
                    });


        //* CUSTOMER SUPPORT

                //? Question One

                    viewSix.addEventListener('click', function() {  // View Answer Btn
                        answerSix.style.display = 'block';
                        viewSix.style.display = 'none';
                        hideSix.style.display = 'block';
                    });

                    hideSix.addEventListener('click', function() {  // Hide Answer Btn
                        answerSix.style.display = 'none';
                        viewSix.style.display = 'block';
                        hideSix.style.display = 'none';
                    });