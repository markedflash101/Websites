

    const images = new Array(); // This is the array of images that will be preloaded

    function preloadImages() { // This is the function that preloads each of the images on the site

        for (i=0; i < preloadImages.arguments.length; i++) {

            images[i] = new Image();

            images[i].src = preloadImages.arguments[i]; // images[i].src is the arguments inside of the images array

        }

    }


//! The images that need to be preloaded

    preloadImages(

                //? Nav
                'imgs/nav/nav-img.jpg',
                //? Index
                'imgs/index/hero-slide-1.jpg',
                'imgs/index/hero-slide-2.jpg',
                'imgs/index/hero-slide-3.jpg',
                'imgs/index/recommended-products-img1.jpg',
                'imgs/index/recommended-products-img2.jpg',
                'imgs/index/recommended-products-img3.jpg',
                'imgs/index/top-collections-img-1.jpg',
                'imgs/index/top-collections-img-2.jpg',
                'imgs/index/top-collections-img-3.jpg',
                'imgs/index/under-carousel-L-bg.jpg',
                'imgs/index/under-carousel-R-bg.jpg',
                //? Support
                'imgs/support/support-top-bg.jpeg',
                'imgs/support/support-top-bg-revamp.jpeg',
                //? Footer
                'imgs/footer/footer-logo-img.jpg'
                
                );