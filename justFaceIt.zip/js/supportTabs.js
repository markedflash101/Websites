

function openPage(pageName, element, color) {

    // This will hide all of the elements with class="tabcontent"
    let i, tabContent, tabLinks;
    tabContent = document.getElementsByClassName('tabcontent');
    for (i = 0; i < tabContent.length; i++) {
        tabContent[i].style.display = 'none';
    }


    // This removes the background color of all tablinks/buttons
    tabLinks = document.getElementsByClassName('tablink');
    for (i = 0; i < tabLinks.length; i++) {
        tabLinks[i].style.backgroundColor = '';
    }

    
    // This shows the specific tab content
    document.getElementById(pageName).style.display = 'block';

    // This adds the specific color to the tab content
    element.style.backgroundColor = color;
    element.style.color = 'white';

}



// This gets the element with the id='defaultOpen' and click on it 
document.getElementById('defaultOpen').click();