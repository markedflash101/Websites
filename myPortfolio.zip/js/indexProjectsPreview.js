
//? Desktop

    const projectOneMainOne = document.getElementById('p1m1');
    const projectOneMainTwo = document.getElementById('p1m2');
    const projectOneMainThree = document.getElementById('p1m3');


    const projectOneSubOne = document.getElementById('p1s1');
    const projectOneSubTwo = document.getElementById('p1s2');
    const projectOneSubThree = document.getElementById('p1s3');


    projectOneSubOne.addEventListener('click', function() {

        projectOneMainOne.style.display = 'block';
        projectOneMainTwo.style.display = 'none';
        projectOneMainThree.style.display = 'none';

    });


    projectOneSubTwo.addEventListener('click', function() {

        projectOneMainOne.style.display = 'none';
        projectOneMainTwo.style.display = 'block';
        projectOneMainThree.style.display = 'none';

    });


    projectOneSubThree.addEventListener('click', function() {

        projectOneMainOne.style.display = 'none';
        projectOneMainTwo.style.display = 'none';
        projectOneMainThree.style.display = 'block';

    });



//? Mobile

    const mobileProjectOneMainOne = document.getElementById('mobileP1M1');
    const mobileProjectOneMainTwo = document.getElementById('mobileP1M2');
    const mobileProjectOneMainThree = document.getElementById('mobileP1M3');


    const mobileProjectOneSubOne = document.getElementById('mobileP1S1');
    const mobileProjectOneSubTwo = document.getElementById('mobileP1S2');
    const mobileProjectOneSubThree = document.getElementById('mobileP1S3');


    mobileProjectOneSubOne.addEventListener('click', function() {

        mobileProjectOneMainOne.style.display = 'block';
        mobileProjectOneMainTwo.style.display = 'none';
        mobileProjectOneMainThree.style.display = 'none';

    });


    mobileProjectOneSubTwo.addEventListener('click', function() {

        mobileProjectOneMainOne.style.display = 'none';
        mobileProjectOneMainTwo.style.display = 'block';
        mobileProjectOneMainThree.style.display = 'none';

    });


    mobileProjectOneSubThree.addEventListener('click', function() {

        mobileProjectOneMainOne.style.display = 'none';
        mobileProjectOneMainTwo.style.display = 'none';
        mobileProjectOneMainThree.style.display = 'block';

    })