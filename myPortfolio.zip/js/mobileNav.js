

    function toggleNav() {

        const button = document.getElementById('toggleBtn');

        const nav = document.getElementById('mobile-nav-links');


        if (nav.style.display == 'block') {

            nav.style.display = 'none';

            button.innerHTML = '<i class="fas fa-bars"></i>';


        } else {

            nav.style.display = 'block';

            button.innerHTML = '<i class="fas fa-times"></i>';

        }


    }